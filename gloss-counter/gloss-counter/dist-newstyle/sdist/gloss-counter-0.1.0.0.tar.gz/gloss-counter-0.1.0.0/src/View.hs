-- | This module defines how to turn
--   the game state into a picture
module View where
import Graphics.Gloss
import Graphics.Gloss.Data.Picture (Picture (Bitmap, BitmapSection, Blank) , pictures, scale, translate, bitmapSection)
import Model ( GameState (LevelSelectState) )
import Graphics.Gloss.Interface.IO.Animate (animateIO)
import Graphics.Gloss.Data.Bitmap (BitmapData(bitmapSize), Rectangle (Rectangle), loadBMP)


view :: GameState -> IO Picture
view g  = do
                hario <- getHario
                hario <- pure (scale 0.5 0.5 hario)
                hario <- pure (translate (-400) 0 hario)

                hario2 <- getHario
                hario2 <- pure (scale 0.5 0.5 hario2)
                hario2 <- pure (translate 400 0 hario2)

                harioAnimationSheet <- getHarioAnimationSheet

                let harioSprites = makeListofSheet (Rectangle (0, 0) (17, -35)) harioAnimationSheet

                return (pictures ([hario, hario2] ++ harioSprites))

getHario :: IO BitmapData
getHario = do 
                p@(Bitmap bmpData) <- loadBMP "media/Super_Hario_Bros_Logo.bmp"
                return bmpData

getAnimationSheet1 :: IO BitmapData
getAnimationSheet1 = do 
                        p@(Bitmap bmpData) <- loadBMP "media/hario_and_items.bmp"
                        return bmpData


getHarioAnimationSheet :: IO Picture
getHarioAnimationSheet = do
                            harioSheet <- getAnimationSheet1

                            let harioSheetbmp = harioSheet
                            return (bitmapSection (Rectangle (0, 0) (270, -35)) harioSheetbmp )

getFireHarioAnimationSheet :: IO Picture
getFireHarioAnimationSheet = do
                                fireHarioSheet <- getAnimationSheet1
                                let fireHarioSheetbmp = fireHarioSheet
                                return (bitmapSection (Rectangle (0, -35) (360, -71)) fireHarioSheetbmp)

getSmallHarioAnimationSheet :: IO Picture
getSmallHarioAnimationSheet = do
                                smallHarioSheet <- getAnimationSheet1
                                let smallHarioSheetbmp = smallHarioSheet
                                return (bitmapSection (Rectangle (0, -71) (251, -89)) smallHarioSheetbmp)

makeListofSheet :: Rectangle -> BitmapData -> [Picture]
makeListofSheet r@(Rectangle (x,y) (w,h)) bmp   | fst (bitmapSize bitmp) >= w  = BitmapSection r bitmp : makeListofSheet r (BitmapSection (Rectangle (x+w, y) (wd, h)) bitmp)
                                                | otherwise = [Blank]
                                                where
                                                    wd = fst (bitmapSize bmp) - w
                                                    bitmp = bmp


-- | 270x-35px for normal hario
-- | 360x-71px from (0, -35) for fire hario
-- | 251x-89px from (0, -71) for small hario

-- | normal hario = 17x35px per sprite, fire hario is 1px taller
-- | small hario = 15x18px per sprite 